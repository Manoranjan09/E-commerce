import { User, AuthState } from './types';

const AUTH_TOKEN_KEY = 'cartfusion_auth_token';
const USER_DATA_KEY = 'cartfusion_user_data';

// Mock user database
const mockUsers: Array<{ email: string; password: string; name: string; id: string }> = [
  { id: '1', email: 'demo@cartfusion.com', password: 'password123', name: 'Demo User' }
];

export const authService = {
  // Simulate JWT token generation
  generateToken: (userId: string): string => {
    const payload = { userId, exp: Date.now() + 24 * 60 * 60 * 1000 }; // 24 hours
    return btoa(JSON.stringify(payload));
  },

  // Validate token
  validateToken: (token: string): boolean => {
    try {
      const payload = JSON.parse(atob(token));
      return payload.exp > Date.now();
    } catch {
      return false;
    }
  },

  // Extract user ID from token
  getUserIdFromToken: (token: string): string | null => {
    try {
      const payload = JSON.parse(atob(token));
      return payload.userId;
    } catch {
      return null;
    }
  },

  // Login
  login: async (email: string, password: string): Promise<User> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const user = mockUsers.find(u => u.email === email && u.password === password);
    if (!user) {
      throw new Error('Invalid credentials');
    }

    const token = authService.generateToken(user.id);
    const userData: User = {
      id: user.id,
      email: user.email,
      name: user.name,
      token
    };

    localStorage.setItem(AUTH_TOKEN_KEY, token);
    localStorage.setItem(USER_DATA_KEY, JSON.stringify(userData));

    return userData;
  },

  // Register
  register: async (email: string, password: string, name: string): Promise<User> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const existingUser = mockUsers.find(u => u.email === email);
    if (existingUser) {
      throw new Error('User already exists');
    }

    const newUser = {
      id: Date.now().toString(),
      email,
      password,
      name
    };

    mockUsers.push(newUser);

    const token = authService.generateToken(newUser.id);
    const userData: User = {
      id: newUser.id,
      email: newUser.email,
      name: newUser.name,
      token
    };

    localStorage.setItem(AUTH_TOKEN_KEY, token);
    localStorage.setItem(USER_DATA_KEY, JSON.stringify(userData));

    return userData;
  },

  // Logout
  logout: (): void => {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(USER_DATA_KEY);
  },

  // Get current user
  getCurrentUser: (): User | null => {
    const token = localStorage.getItem(AUTH_TOKEN_KEY);
    const userData = localStorage.getItem(USER_DATA_KEY);

    if (!token || !userData || !authService.validateToken(token)) {
      authService.logout();
      return null;
    }

    return JSON.parse(userData);
  },

  // Get auth state
  getAuthState: (): AuthState => {
    const user = authService.getCurrentUser();
    return {
      user,
      isAuthenticated: !!user,
      token: user?.token || null
    };
  }
};