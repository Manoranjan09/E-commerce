import { Product, Cart, CartItem, ProductFilters } from './types';
import { authService } from './auth';

// Mock product database
const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Wireless Headphones',
    description: 'High-quality wireless headphones with noise cancellation',
    price: 199.99,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=300&fit=crop',
    stock: 50
  },
  {
    id: '2',
    name: 'Smart Watch',
    description: 'Feature-rich smartwatch with health monitoring',
    price: 299.99,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=300&fit=crop',
    stock: 30
  },
  {
    id: '3',
    name: 'Running Shoes',
    description: 'Comfortable running shoes for all terrains',
    price: 129.99,
    category: 'Sports',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=300&fit=crop',
    stock: 75
  },
  {
    id: '4',
    name: 'Coffee Maker',
    description: 'Automatic coffee maker with programmable settings',
    price: 89.99,
    category: 'Home',
    image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400&h=300&fit=crop',
    stock: 25
  },
  {
    id: '5',
    name: 'Backpack',
    description: 'Durable backpack perfect for travel and daily use',
    price: 59.99,
    category: 'Fashion',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=300&fit=crop',
    stock: 40
  },
  {
    id: '6',
    name: 'Bluetooth Speaker',
    description: 'Portable Bluetooth speaker with excellent sound quality',
    price: 79.99,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&h=300&fit=crop',
    stock: 60
  }
];

const CART_STORAGE_KEY = 'cartfusion_cart';

export const apiService = {
  // Products API
  getProducts: async (filters?: ProductFilters): Promise<Product[]> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    let filteredProducts = [...mockProducts];

    if (filters) {
      if (filters.category) {
        filteredProducts = filteredProducts.filter(p => p.category === filters.category);
      }
      if (filters.minPrice !== undefined) {
        filteredProducts = filteredProducts.filter(p => p.price >= filters.minPrice!);
      }
      if (filters.maxPrice !== undefined) {
        filteredProducts = filteredProducts.filter(p => p.price <= filters.maxPrice!);
      }
      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        filteredProducts = filteredProducts.filter(p => 
          p.name.toLowerCase().includes(searchLower) ||
          p.description.toLowerCase().includes(searchLower)
        );
      }
    }

    return filteredProducts;
  },

  getProduct: async (id: string): Promise<Product | null> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    return mockProducts.find(p => p.id === id) || null;
  },

  getCategories: async (): Promise<string[]> => {
    await new Promise(resolve => setTimeout(resolve, 200));
    return [...new Set(mockProducts.map(p => p.category))];
  },

  // Cart API
  getCart: async (): Promise<Cart> => {
    const user = authService.getCurrentUser();
    if (!user) {
      throw new Error('User not authenticated');
    }

    const cartData = localStorage.getItem(`${CART_STORAGE_KEY}_${user.id}`);
    if (!cartData) {
      return {
        id: `cart_${user.id}`,
        userId: user.id,
        items: [],
        total: 0
      };
    }

    return JSON.parse(cartData);
  },

  addToCart: async (productId: string, quantity: number = 1): Promise<Cart> => {
    const user = authService.getCurrentUser();
    if (!user) {
      throw new Error('User not authenticated');
    }

    const product = await apiService.getProduct(productId);
    if (!product) {
      throw new Error('Product not found');
    }

    const cart = await apiService.getCart();
    const existingItem = cart.items.find(item => item.productId === productId);

    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      const newItem: CartItem = {
        id: `item_${Date.now()}`,
        productId,
        product,
        quantity
      };
      cart.items.push(newItem);
    }

    cart.total = cart.items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    
    localStorage.setItem(`${CART_STORAGE_KEY}_${user.id}`, JSON.stringify(cart));
    return cart;
  },

  removeFromCart: async (itemId: string): Promise<Cart> => {
    const user = authService.getCurrentUser();
    if (!user) {
      throw new Error('User not authenticated');
    }

    const cart = await apiService.getCart();
    cart.items = cart.items.filter(item => item.id !== itemId);
    cart.total = cart.items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    
    localStorage.setItem(`${CART_STORAGE_KEY}_${user.id}`, JSON.stringify(cart));
    return cart;
  },

  updateCartItemQuantity: async (itemId: string, quantity: number): Promise<Cart> => {
    const user = authService.getCurrentUser();
    if (!user) {
      throw new Error('User not authenticated');
    }

    const cart = await apiService.getCart();
    const item = cart.items.find(item => item.id === itemId);
    
    if (item) {
      if (quantity <= 0) {
        return apiService.removeFromCart(itemId);
      }
      item.quantity = quantity;
      cart.total = cart.items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
      localStorage.setItem(`${CART_STORAGE_KEY}_${user.id}`, JSON.stringify(cart));
    }

    return cart;
  },

  clearCart: async (): Promise<Cart> => {
    const user = authService.getCurrentUser();
    if (!user) {
      throw new Error('User not authenticated');
    }

    const emptyCart: Cart = {
      id: `cart_${user.id}`,
      userId: user.id,
      items: [],
      total: 0
    };

    localStorage.setItem(`${CART_STORAGE_KEY}_${user.id}`, JSON.stringify(emptyCart));
    return emptyCart;
  }
};