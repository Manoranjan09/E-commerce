import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Heart, 
  Brain, 
  Bone, 
  Baby, 
  Stethoscope, 
  Ambulance,
  Eye,
  Ear,
  Scissors,
  Activity,
  Pill,
  Shield,
  Clock,
  Users
} from 'lucide-react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function ServicesPage() {
  const departments = [
    {
      icon: <Heart className="w-12 h-12 text-red-500" />,
      title: "Cardiology",
      description: "Comprehensive heart and cardiovascular care including diagnostics, treatments, and surgical procedures.",
      services: ["ECG & Echo", "Cardiac Catheterization", "Heart Surgery", "Pacemaker Implantation"],
      image: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
    },
    {
      icon: <Brain className="w-12 h-12 text-purple-500" />,
      title: "Neurology",
      description: "Advanced neurological care for brain, spine, and nervous system disorders.",
      services: ["MRI & CT Scans", "Neurosurgery", "Stroke Treatment", "Epilepsy Care"],
      image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
    },
    {
      icon: <Bone className="w-12 h-12 text-blue-500" />,
      title: "Orthopedics",
      description: "Expert care for bones, joints, muscles, and sports-related injuries.",
      services: ["Joint Replacement", "Sports Medicine", "Fracture Care", "Physical Therapy"],
      image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
    },
    {
      icon: <Baby className="w-12 h-12 text-pink-500" />,
      title: "Pediatrics",
      description: "Specialized medical care for infants, children, and adolescents.",
      services: ["Well-child Visits", "Immunizations", "Growth Monitoring", "Pediatric Surgery"],
      image: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
    },
    {
      icon: <Eye className="w-12 h-12 text-green-500" />,
      title: "Ophthalmology",
      description: "Complete eye care services including surgery and vision correction.",
      services: ["Cataract Surgery", "LASIK", "Retinal Treatment", "Glaucoma Care"],
      image: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
    },
    {
      icon: <Ear className="w-12 h-12 text-orange-500" />,
      title: "ENT",
      description: "Ear, nose, and throat specialists providing comprehensive care.",
      services: ["Hearing Tests", "Sinus Surgery", "Throat Procedures", "Allergy Treatment"],
      image: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
    }
  ];

  const facilities = [
    {
      icon: <Shield className="w-8 h-8 text-blue-500" />,
      title: "ICU & Critical Care",
      description: "Advanced intensive care units with 24/7 monitoring"
    },
    {
      icon: <Pill className="w-8 h-8 text-green-500" />,
      title: "Pharmacy Services",
      description: "Full-service pharmacy with medication counseling"
    },
    {
      icon: <Activity className="w-8 h-8 text-purple-500" />,
      title: "Laboratory Services",
      description: "Comprehensive diagnostic testing and pathology"
    },
    {
      icon: <Clock className="w-8 h-8 text-orange-500" />,
      title: "24/7 Emergency",
      description: "Round-the-clock emergency medical services"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6">Our Medical Services</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Comprehensive healthcare services delivered with excellence and compassion by our expert medical team
          </p>
        </div>
      </section>

      {/* Departments Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Medical Departments
            </h2>
            <p className="text-xl text-gray-600">
              Specialized care across multiple medical disciplines
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {departments.map((dept, index) => (
              <Card key={index} className="hover:shadow-xl transition-all duration-300">
                <div className="flex flex-col md:flex-row">
                  <div className="md:w-1/3">
                    <img 
                      src={dept.image} 
                      alt={dept.title}
                      className="w-full h-48 md:h-full object-cover rounded-t-lg md:rounded-l-lg md:rounded-t-none"
                    />
                  </div>
                  <div className="md:w-2/3 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center space-x-3 mb-2">
                        {dept.icon}
                        <CardTitle className="text-2xl">{dept.title}</CardTitle>
                      </div>
                      <CardDescription className="text-base">
                        {dept.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="space-y-2">
                        <h4 className="font-semibold text-gray-900">Services Include:</h4>
                        <div className="flex flex-wrap gap-2">
                          {dept.services.map((service, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {service}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Facilities Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Hospital Facilities
            </h2>
            <p className="text-xl text-gray-600">
              State-of-the-art facilities and equipment for comprehensive care
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {facilities.map((facility, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow duration-300">
                <CardContent className="pt-8">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
                    {facility.icon}
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{facility.title}</h3>
                  <p className="text-gray-600">{facility.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Emergency Services */}
      <section className="py-20 bg-red-600 text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <Ambulance className="w-12 h-12" />
                <h2 className="text-3xl lg:text-4xl font-bold">Emergency Services</h2>
              </div>
              <p className="text-xl text-red-100 mb-6">
                Our emergency department is equipped to handle all types of medical emergencies 
                with rapid response times and expert care.
              </p>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Clock className="w-6 h-6" />
                  <span className="text-lg">24/7 Emergency Care</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Users className="w-6 h-6" />
                  <span className="text-lg">Trauma Specialists On-Site</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Activity className="w-6 h-6" />
                  <span className="text-lg">Advanced Life Support</span>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg p-8 text-gray-900">
              <h3 className="text-2xl font-bold mb-4">Emergency Contact</h3>
              <div className="space-y-4">
                <div>
                  <p className="font-semibold">Emergency Hotline</p>
                  <p className="text-2xl font-bold text-red-600">+1 (555) 911-HELP</p>
                </div>
                <div>
                  <p className="font-semibold">Ambulance Services</p>
                  <p className="text-lg">+1 (555) 911-AMBU</p>
                </div>
                <div>
                  <p className="font-semibold">Location</p>
                  <p>123 Medical Center Dr, Health City</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
            Need Medical Care?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Schedule an appointment with our specialists or visit our emergency department
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg">
              <Link to="/appointments">Book Appointment</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/doctors">Find a Doctor</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}