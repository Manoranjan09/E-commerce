# Hospital Management System - MVP Implementation

## Core Features to Implement:
1. **Homepage** - Hospital overview, services, contact info
2. **Services Page** - Medical departments and specialties
3. **Doctors Page** - Doctor profiles and specializations
4. **Appointment Booking** - Schedule appointments with doctors
5. **Login System** - Separate login for patients and admin/authority
6. **Admin Dashboard** - Management interface for hospital staff
7. **Patient Dashboard** - View appointments and medical records
8. **Emergency Services** - Emergency contact and procedures

## Files to Create:
1. `src/pages/Index.tsx` - Homepage (rewrite existing)
2. `src/pages/Services.tsx` - Medical services and departments
3. `src/pages/Doctors.tsx` - Doctor profiles
4. `src/pages/Appointments.tsx` - Appointment booking system
5. `src/pages/Login.tsx` - Patient login
6. `src/pages/AdminLogin.tsx` - Admin/Authority login
7. `src/pages/Dashboard.tsx` - Patient dashboard
8. `src/pages/AdminDashboard.tsx` - Admin dashboard
9. `src/components/Navbar.tsx` - Navigation component
10. `src/components/Footer.tsx` - Footer component
11. `src/App.tsx` - Update routing
12. `index.html` - Update title

## Key Components:
- Navigation with hospital branding
- Hero section with hospital image
- Services grid with icons
- Doctor cards with photos
- Appointment form with date/time picker
- Login forms with validation
- Dashboard with appointment history
- Admin panel for managing appointments

## Images to Include:
- Hospital building exterior
- Medical equipment
- Doctor portraits
- Medical icons and illustrations
- Emergency services imagery

## Tech Stack:
- React + TypeScript
- Shadcn/UI components
- Tailwind CSS for styling
- React Router for navigation
- Local storage for demo data