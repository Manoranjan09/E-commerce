import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Search,
  MapPin,
  Phone,
  Mail,
  Calendar,
  Star,
  Award,
  GraduationCap
} from 'lucide-react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function DoctorsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');

  const doctors = [
    {
      id: 1,
      name: "Dr. Sarah Johnson",
      specialty: "Cardiology",
      title: "Chief of Cardiology",
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      experience: "15+ years",
      education: "Harvard Medical School",
      rating: 4.9,
      reviews: 127,
      languages: ["English", "Spanish"],
      specializations: ["Interventional Cardiology", "Heart Failure", "Cardiac Surgery"],
      phone: "+1 (555) 123-4567",
      email: "s.johnson@medicare-hospital.com"
    },
    {
      id: 2,
      name: "Dr. Michael Chen",
      specialty: "Neurology",
      title: "Senior Neurosurgeon",
      image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      experience: "20+ years",
      education: "Johns Hopkins University",
      rating: 4.8,
      reviews: 98,
      languages: ["English", "Mandarin"],
      specializations: ["Brain Surgery", "Spine Surgery", "Tumor Removal"],
      phone: "+1 (555) 123-4568",
      email: "m.chen@medicare-hospital.com"
    },
    {
      id: 3,
      name: "Dr. Emily Rodriguez",
      specialty: "Pediatrics",
      title: "Pediatric Specialist",
      image: "https://images.unsplash.com/photo-1594824475317-8e3d5e3a5e3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      experience: "12+ years",
      education: "Stanford Medical School",
      rating: 4.9,
      reviews: 156,
      languages: ["English", "Spanish", "Portuguese"],
      specializations: ["Pediatric Care", "Child Development", "Immunizations"],
      phone: "+1 (555) 123-4569",
      email: "e.rodriguez@medicare-hospital.com"
    },
    {
      id: 4,
      name: "Dr. James Wilson",
      specialty: "Orthopedics",
      title: "Orthopedic Surgeon",
      image: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      experience: "18+ years",
      education: "Mayo Clinic College",
      rating: 4.7,
      reviews: 89,
      languages: ["English"],
      specializations: ["Joint Replacement", "Sports Medicine", "Trauma Surgery"],
      phone: "+1 (555) 123-4570",
      email: "j.wilson@medicare-hospital.com"
    },
    {
      id: 5,
      name: "Dr. Lisa Park",
      specialty: "Ophthalmology",
      title: "Eye Specialist",
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      experience: "10+ years",
      education: "UCLA Medical School",
      rating: 4.8,
      reviews: 73,
      languages: ["English", "Korean"],
      specializations: ["Cataract Surgery", "LASIK", "Retinal Disorders"],
      phone: "+1 (555) 123-4571",
      email: "l.park@medicare-hospital.com"
    },
    {
      id: 6,
      name: "Dr. Robert Thompson",
      specialty: "Emergency Medicine",
      title: "Emergency Department Chief",
      image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      experience: "22+ years",
      education: "University of Pennsylvania",
      rating: 4.9,
      reviews: 134,
      languages: ["English", "French"],
      specializations: ["Trauma Care", "Critical Care", "Emergency Surgery"],
      phone: "+1 (555) 911-HELP",
      email: "r.thompson@medicare-hospital.com"
    }
  ];

  const specialties = [
    "Cardiology",
    "Neurology", 
    "Pediatrics",
    "Orthopedics",
    "Ophthalmology",
    "Emergency Medicine"
  ];

  const filteredDoctors = doctors.filter(doctor => {
    const matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecialty = selectedSpecialty === 'all' || doctor.specialty === selectedSpecialty;
    return matchesSearch && matchesSpecialty;
  });

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6">Meet Our Expert Doctors</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            World-class physicians dedicated to providing exceptional healthcare with compassion and expertise
          </p>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  placeholder="Search doctors by name or specialty..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by specialty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Specialties</SelectItem>
                  {specialties.map((specialty) => (
                    <SelectItem key={specialty} value={specialty}>
                      {specialty}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>

      {/* Doctors Grid */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredDoctors.map((doctor) => (
              <Card key={doctor.id} className="hover:shadow-xl transition-all duration-300">
                <CardContent className="p-6">
                  <div className="text-center mb-6">
                    <img 
                      src={doctor.image} 
                      alt={doctor.name}
                      className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                    />
                    <h3 className="text-xl font-bold text-gray-900 mb-1">{doctor.name}</h3>
                    <p className="text-blue-600 font-semibold mb-2">{doctor.title}</p>
                    <Badge variant="secondary" className="mb-2">
                      {doctor.specialty}
                    </Badge>
                    <div className="flex items-center justify-center space-x-1 mb-2">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="text-sm font-medium">{doctor.rating}</span>
                      <span className="text-sm text-gray-500">({doctor.reviews} reviews)</span>
                    </div>
                  </div>

                  <div className="space-y-3 text-sm">
                    <div className="flex items-center space-x-2">
                      <Award className="w-4 h-4 text-gray-400" />
                      <span>{doctor.experience} Experience</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <GraduationCap className="w-4 h-4 text-gray-400" />
                      <span>{doctor.education}</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-700 mb-1">Specializations:</p>
                      <div className="flex flex-wrap gap-1">
                        {doctor.specializations.map((spec, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {spec}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="font-medium text-gray-700 mb-1">Languages:</p>
                      <p className="text-gray-600">{doctor.languages.join(', ')}</p>
                    </div>
                  </div>

                  <div className="mt-6 space-y-2">
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <Phone className="w-4 h-4" />
                      <span>{doctor.phone}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <Mail className="w-4 h-4" />
                      <span className="truncate">{doctor.email}</span>
                    </div>
                  </div>

                  <div className="mt-6 space-y-2">
                    <Button asChild className="w-full">
                      <Link to="/appointments">
                        <Calendar className="w-4 h-4 mr-2" />
                        Book Appointment
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full">
                      View Profile
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredDoctors.length === 0 && (
            <div className="text-center py-12">
              <p className="text-xl text-gray-600">No doctors found matching your search criteria.</p>
              <Button 
                onClick={() => {
                  setSearchTerm('');
                  setSelectedSpecialty('all');
                }}
                className="mt-4"
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Ready to Schedule Your Appointment?
          </h2>
          <p className="text-xl mb-8 text-blue-100">
            Choose from our expert physicians and book your consultation today
          </p>
          <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
            <Link to="/appointments">
              <Calendar className="w-5 h-5 mr-2" />
              Book Appointment Now
            </Link>
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
}