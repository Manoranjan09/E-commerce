import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Heart, 
  Brain, 
  Bone, 
  Baby, 
  Stethoscope, 
  Ambulance, 
  Clock, 
  Users, 
  Award,
  Phone,
  Calendar,
  Shield
} from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function HomePage() {
  const services = [
    {
      icon: <Heart className="w-8 h-8 text-red-500" />,
      title: "Cardiology",
      description: "Advanced heart care and cardiovascular treatments"
    },
    {
      icon: <Brain className="w-8 h-8 text-purple-500" />,
      title: "Neurology",
      description: "Expert neurological care and brain treatments"
    },
    {
      icon: <Bone className="w-8 h-8 text-blue-500" />,
      title: "Orthopedics",
      description: "Comprehensive bone and joint care"
    },
    {
      icon: <Baby className="w-8 h-8 text-pink-500" />,
      title: "Pediatrics",
      description: "Specialized care for children and infants"
    },
    {
      icon: <Stethoscope className="w-8 h-8 text-green-500" />,
      title: "General Medicine",
      description: "Primary healthcare and preventive medicine"
    },
    {
      icon: <Ambulance className="w-8 h-8 text-red-600" />,
      title: "Emergency Care",
      description: "24/7 emergency medical services"
    }
  ];

  const stats = [
    { number: "50+", label: "Years of Excellence", icon: <Award className="w-6 h-6" /> },
    { number: "200+", label: "Expert Doctors", icon: <Users className="w-6 h-6" /> },
    { number: "24/7", label: "Emergency Care", icon: <Clock className="w-6 h-6" /> },
    { number: "500+", label: "Beds Available", icon: <Shield className="w-6 h-6" /> }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <Badge className="bg-white text-blue-600 hover:bg-gray-100">
                Excellence in Healthcare Since 1974
              </Badge>
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                Your Health is Our
                <span className="text-yellow-400"> Priority</span>
              </h1>
              <p className="text-xl text-blue-100">
                Providing world-class medical care with compassion, innovation, and excellence. 
                Our team of expert doctors and state-of-the-art facilities ensure the best possible outcomes.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                  <Link to="/appointments">
                    <Calendar className="w-5 h-5 mr-2" />
                    Book Appointment
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                  <Link to="/services">
                    View Services
                  </Link>
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="bg-white rounded-lg p-8 shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                  alt="Modern Hospital Building" 
                  className="w-full h-64 object-cover rounded-lg"
                />
                <div className="mt-4 text-center text-gray-800">
                  <h3 className="font-semibold">MediCare Hospital</h3>
                  <p className="text-sm text-gray-600">State-of-the-art Medical Facility</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Banner */}
      <section className="bg-red-600 text-white py-4">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row items-center justify-between">
            <div className="flex items-center space-x-3">
              <Phone className="w-6 h-6" />
              <span className="font-semibold">24/7 Emergency Hotline: +1 (555) 911-HELP</span>
            </div>
            <Button variant="outline" size="sm" className="border-white text-white hover:bg-white hover:text-red-600 mt-2 sm:mt-0">
              Emergency Services
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                  <div className="text-blue-600">{stat.icon}</div>
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Our Medical Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive healthcare services delivered by our team of experienced medical professionals
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    {service.icon}
                    <CardTitle className="text-xl">{service.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {service.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Button asChild size="lg">
              <Link to="/services">View All Services</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Doctors */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Meet Our Expert Doctors
            </h2>
            <p className="text-xl text-gray-600">
              World-class physicians dedicated to your health and wellbeing
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Dr. Sarah Johnson",
                specialty: "Chief of Cardiology",
                image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
                experience: "15+ years"
              },
              {
                name: "Dr. Michael Chen",
                specialty: "Neurosurgeon",
                image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
                experience: "20+ years"
              },
              {
                name: "Dr. Emily Rodriguez",
                specialty: "Pediatric Specialist",
                image: "https://images.unsplash.com/photo-1594824475317-8e3d5e3a5e3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
                experience: "12+ years"
              }
            ].map((doctor, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow duration-300">
                <CardContent className="pt-6">
                  <img 
                    src={doctor.image} 
                    alt={doctor.name}
                    className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                  />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{doctor.name}</h3>
                  <p className="text-blue-600 font-medium mb-1">{doctor.specialty}</p>
                  <p className="text-gray-600">{doctor.experience} Experience</p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Button asChild size="lg" variant="outline">
              <Link to="/doctors">View All Doctors</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Ready to Schedule Your Appointment?
          </h2>
          <p className="text-xl mb-8 text-blue-100">
            Take the first step towards better health. Our medical team is here to help you.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
              <Link to="/appointments">
                <Calendar className="w-5 h-5 mr-2" />
                Book Appointment
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
              <Link to="/login">
                Patient Portal
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}