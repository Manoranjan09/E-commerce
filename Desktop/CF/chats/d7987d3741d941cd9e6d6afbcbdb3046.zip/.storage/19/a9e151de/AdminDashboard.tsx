import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Calendar,
  Users,
  Activity,
  TrendingUp,
  Clock,
  Phone,
  Mail,
  Settings,
  LogOut,
  UserPlus,
  FileText,
  Bed,
  Stethoscope,
  AlertTriangle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview');

  const todayStats = {
    totalPatients: 156,
    newPatients: 12,
    appointments: 45,
    emergencies: 3,
    occupiedBeds: 78,
    totalBeds: 120,
    availableDoctors: 23,
    totalDoctors: 28
  };

  const recentAppointments = [
    {
      id: 1,
      patient: 'John Smith',
      doctor: 'Dr. Sarah Johnson',
      time: '09:00 AM',
      type: 'Cardiology',
      status: 'confirmed'
    },
    {
      id: 2,
      patient: 'Mary Wilson',
      doctor: 'Dr. Michael Chen',
      time: '09:30 AM',
      type: 'Neurology',
      status: 'in-progress'
    },
    {
      id: 3,
      patient: 'Robert Brown',
      doctor: 'Dr. Emily Rodriguez',
      time: '10:00 AM',
      type: 'Pediatrics',
      status: 'waiting'
    }
  ];

  const emergencyAlerts = [
    {
      id: 1,
      type: 'critical',
      message: 'ICU Bed 5 - Patient requires immediate attention',
      time: '5 minutes ago'
    },
    {
      id: 2,
      type: 'warning',
      message: 'Emergency Department at 85% capacity',
      time: '15 minutes ago'
    }
  ];

  const staffOnDuty = [
    {
      name: 'Dr. Sarah Johnson',
      role: 'Cardiologist',
      status: 'available',
      patients: 8
    },
    {
      name: 'Dr. Michael Chen',
      role: 'Neurologist',
      status: 'busy',
      patients: 12
    },
    {
      name: 'Nurse Jane Smith',
      role: 'Head Nurse',
      status: 'available',
      patients: 15
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Header */}
      <section className="bg-white border-b py-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <Avatar className="w-12 h-12">
                <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80" />
                <AvatarFallback>AD</AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
                <p className="text-gray-600">MediCare Hospital Management System</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
              <Button variant="outline" size="sm">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Dashboard Content */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Total Patients</p>
                    <p className="text-2xl font-bold">{todayStats.totalPatients}</p>
                    <p className="text-xs text-green-600">+{todayStats.newPatients} new today</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <Calendar className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Appointments</p>
                    <p className="text-2xl font-bold">{todayStats.appointments}</p>
                    <p className="text-xs text-gray-500">Today's schedule</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-red-100 rounded-lg">
                    <AlertTriangle className="w-6 h-6 text-red-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Emergencies</p>
                    <p className="text-2xl font-bold">{todayStats.emergencies}</p>
                    <p className="text-xs text-red-600">Active cases</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <Bed className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Bed Occupancy</p>
                    <p className="text-2xl font-bold">{todayStats.occupiedBeds}/{todayStats.totalBeds}</p>
                    <p className="text-xs text-gray-500">{Math.round((todayStats.occupiedBeds / todayStats.totalBeds) * 100)}% occupied</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Recent Appointments */}
            <Card>
              <CardHeader>
                <CardTitle>Today's Appointments</CardTitle>
                <CardDescription>Current appointment schedule</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentAppointments.map((appointment) => (
                    <div key={appointment.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <h4 className="font-semibold">{appointment.patient}</h4>
                        <p className="text-sm text-gray-600">{appointment.doctor}</p>
                        <p className="text-xs text-gray-500">{appointment.type} - {appointment.time}</p>
                      </div>
                      <Badge variant={
                        appointment.status === 'confirmed' ? 'default' :
                        appointment.status === 'in-progress' ? 'secondary' : 'outline'
                      }>
                        {appointment.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Emergency Alerts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5 text-red-500" />
                  <span>Emergency Alerts</span>
                </CardTitle>
                <CardDescription>Critical notifications and alerts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {emergencyAlerts.map((alert) => (
                    <div key={alert.id} className={`p-3 border rounded-lg ${
                      alert.type === 'critical' ? 'border-red-200 bg-red-50' :
                      alert.type === 'warning' ? 'border-yellow-200 bg-yellow-50' :
                      'border-blue-200 bg-blue-50'
                    }`}>
                      <p className="text-sm font-medium">{alert.message}</p>
                      <p className="text-xs text-gray-500 mt-1">{alert.time}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Staff on Duty */}
            <Card>
              <CardHeader>
                <CardTitle>Staff on Duty</CardTitle>
                <CardDescription>Current medical staff availability</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {staffOnDuty.map((staff, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-8 h-8">
                          <AvatarFallback>{staff.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-semibold text-sm">{staff.name}</h4>
                          <p className="text-xs text-gray-600">{staff.role}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant={staff.status === 'available' ? 'default' : 'secondary'}>
                          {staff.status}
                        </Badge>
                        <p className="text-xs text-gray-500 mt-1">{staff.patients} patients</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Common administrative tasks</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button className="w-full justify-start">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add New Patient
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Calendar className="w-4 h-4 mr-2" />
                  Manage Appointments
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Bed className="w-4 h-4 mr-2" />
                  Bed Management
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <FileText className="w-4 h-4 mr-2" />
                  Generate Reports
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}